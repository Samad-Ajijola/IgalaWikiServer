const Event = require("../models/event");
const upload = require("../middlewares/upload"); 

const eventCtrl = {
  createEvent: async (req, res) => {
    try {
      const { name, description, image, galleryImages } = req.body;

      // Upload main image
      const uploadedImage = await upload.uploader.upload(image, {
        folder: "IgalaEventsFolder",
      });

      let uploadedGallery = [];

      if (galleryImages && galleryImages.length > 0) {
        for (let img of galleryImages) {
          const result = await upload.uploader.upload(img, {
            folder: "IgalaEventsFolder/gallery",
          });
          uploadedGallery.push(result.secure_url);
        }
      }

      const event = await Event.create({
        name,
        description,
        image: uploadedImage.secure_url,
        galleryImages: uploadedGallery,
      });

      res.status(201).json({
        success: true,
        event,
      });
    } catch (error) {
      console.log(error);
      res.status(500).json({
        success: false,
        message: error.message,
      });
    }
  },
};

module.exports = eventCtrl;